/**
 * Title: person.interface.ts
 * Author: Chad ONeal
 * Date: 01/03/2023
 * Description: Person interface
 */

export interface IPerson {
    firstName: string;
    lastName: string;
}